
DROP TABLE IF EXISTS `documents`;
CREATE TABLE IF NOT EXISTS `documents` (
  `idDoc` int(11) NOT NULL AUTO_INCREMENT,
  `dataDoc1` varchar(150) NOT NULL COMMENT 'titre/nom de revue, etc',
  `dataDoc2` varchar(60) NOT NULL COMMENT 'auteur/numero de revue, etc',
  `typeDoc` int(11) NOT NULL COMMENT '1:Livre,2:CD,3:DVD,4:Revue',
  `logUser` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idDoc`),
  KEY `FK_LOGUSER` (`logUser`)
);

INSERT INTO `documents` (`idDoc`, `dataDoc1`, `dataDoc2`, `typeDoc`, `logUser`) VALUES
(1, 'SFML Game development', 'Artur Moreira, Henrik Vogelius Hansson, Jan Haller', 1, NULL),
(3, 'Captain America : Civil War', 'Marvel', 2, NULL),
(4, 'The Beatles Anthology 3', 'The Beatles', 3, 'abo1'),
(5, 'Sciences & Vie', 'Multiples', 4, NULL),
(6, 'livre', 'auteur', 1, NULL);

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `login` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` enum('bibliothecaire','abonne') NOT NULL,
  PRIMARY KEY (`login`)
);


INSERT INTO `users` (`login`, `password`, `type`) VALUES
('abo1', 'abo1', 'abonne'),
('biblio1', 'biblio1', 'bibliothecaire');


ALTER TABLE `documents`
  ADD CONSTRAINT `FK_LOGUSER` FOREIGN KEY (`logUser`) REFERENCES `users` (`login`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;
